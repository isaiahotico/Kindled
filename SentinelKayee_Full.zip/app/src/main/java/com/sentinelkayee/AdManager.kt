package com.sentinelkayee

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView
import java.util.*

object AdManager {
    private const val APP_OPEN_AD_UNIT = "ca-app-pub-1552549628333931/2339118959"
    private const val BANNER_AD_UNIT = "ca-app-pub-1552549628333931/2043605488"
    private const val NATIVE_AD_UNIT = "ca-app-pub-1552549628333931/9501076069"
    private const val REWARDED_INTERSTITIAL_AD_UNIT = "ca-app-pub-1552549628333931/9878110896"

    private const val TEST_APP_OPEN = "ca-app-pub-3940256099942544/3419835294"
    private const val TEST_BANNER = "ca-app-pub-3940256099942544/6300978111"
    private const val TEST_REWARDED_INTERSTITIAL = "ca-app-pub-3940256099942544/5354046379"
    private const val TEST_NATIVE = "ca-app-pub-3940256099942544/2247696110"

    private var rewardedInterstitial: RewardedInterstitialAd? = null
    private var nativeAdCached: NativeAd? = null
    private var appOpenAd: AppOpenAd? = null
    private var isAppOpenShowing = false
    private var lastAppOpenLoadTime: Long = 0
    private const val APP_OPEN_TIMEOUT = 4 * 60 * 60 * 1000

    fun initialize(context: Context) {
        preloadRewardedInterstitial(context)
        preloadNative(context)
        preloadAppOpen(context)
    }

    private fun isAdAvailable(): Boolean {
        return appOpenAd != null && (Date().time - lastAppOpenLoadTime) < APP_OPEN_TIMEOUT
    }

    fun preloadAppOpen(context: Context) {
        val request = AdRequest.Builder().build()
        AppOpenAd.load(context, APP_OPEN_AD_UNIT, request, AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, object: AppOpenAd.AppOpenAdLoadCallback() {
            override fun onAdLoaded(ad: AppOpenAd) {
                appOpenAd = ad
                lastAppOpenLoadTime = Date().time
            }
            override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                AppOpenAd.load(context, TEST_APP_OPEN, request, AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, object: AppOpenAd.AppOpenAdLoadCallback(){
                    override fun onAdLoaded(ad: AppOpenAd) { appOpenAd = ad; lastAppOpenLoadTime = Date().time }
                    override fun onAdFailedToLoad(p0: LoadAdError) {}
                })
            }
        })
    }

    fun showAppOpenIfAvailable(activity: Activity) {
        if (isAppOpenShowing) return
        if (!isAdAvailable()) {
            preloadAppOpen(activity.applicationContext)
            return
        }
        appOpenAd?.fullScreenContentCallback = object: FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                appOpenAd = null
                isAppOpenShowing = false
                preloadAppOpen(activity.applicationContext)
            }
            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                appOpenAd = null
                isAppOpenShowing = false
            }
            override fun onAdShowedFullScreenContent() {
                isAppOpenShowing = true
            }
        }
        appOpenAd?.show(activity)
    }

    fun attachAdaptiveBanner(activity: Activity, container: FrameLayout) {
        container.removeAllViews()
        val adView = AdView(activity)
        adView.adUnitId = BANNER_AD_UNIT
        adView.adSize = getAdSize(activity)
        container.addView(adView)
        val adRequest = AdRequest.Builder().build()
        adView.loadAd(adRequest)
        adView.adListener = object: AdListener() {
            override fun onAdFailedToLoad(error: LoadAdError) {
                adView.adUnitId = TEST_BANNER
                adView.loadAd(AdRequest.Builder().build())
            }
        }
    }

    private fun getAdSize(activity: Activity): AdSize {
        val outMetrics = DisplayMetrics()
        activity.windowManager.defaultDisplay.getMetrics(outMetrics)
        val widthPixels = outMetrics.widthPixels.toFloat()
        val density = outMetrics.density
        val adWidth = (widthPixels / density).toInt()
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, adWidth)
    }

    private fun preloadRewardedInterstitial(context: Context) {
        RewardedInterstitialAd.load(context, REWARDED_INTERSTITIAL_AD_UNIT, AdRequest.Builder().build(), object: RewardedInterstitialAdLoadCallback(){
            override fun onAdLoaded(ad: RewardedInterstitialAd) {
                rewardedInterstitial = ad
            }
            override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                RewardedInterstitialAd.load(context, TEST_REWARDED_INTERSTITIAL, AdRequest.Builder().build(), object: RewardedInterstitialAdLoadCallback(){
                    override fun onAdLoaded(ad: RewardedInterstitialAd) { rewardedInterstitial = ad }
                    override fun onAdFailedToLoad(p0: LoadAdError) {}
                })
            }
        })
    }

    fun showRewardedInterstitial(activity: Activity, onComplete: ()->Unit) {
        rewardedInterstitial?.let { ad ->
            ad.fullScreenContentCallback = object: FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedInterstitial = null
                    preloadRewardedInterstitial(activity.applicationContext)
                    Handler(Looper.getMainLooper()).postDelayed({ onComplete() }, 500)
                }
                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    rewardedInterstitial = null
                    Handler(Looper.getMainLooper()).postDelayed({ onComplete() }, 200)
                }
            }
            ad.show(activity) { rewardItem -> }
        } ?: run {
            preloadRewardedInterstitial(activity.applicationContext)
            Handler(Looper.getMainLooper()).postDelayed({ onComplete() }, 1200)
        }
    }

    private fun preloadNative(context: Context) {
        val builder = com.google.android.gms.ads.AdLoader.Builder(context, NATIVE_AD_UNIT)
            .forNativeAd { ad: NativeAd ->
                nativeAdCached?.destroy()
                nativeAdCached = ad
            }
            .withAdListener(object: AdListener(){
                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    val builderTest = com.google.android.gms.ads.AdLoader.Builder(context, TEST_NATIVE)
                        .forNativeAd { ad: NativeAd -> nativeAdCached?.destroy(); nativeAdCached = ad }
                    builderTest.build().loadAd(AdRequest.Builder().build())
                }
            })
        builder.build().loadAd(AdRequest.Builder().build())
    }

    fun showNative(activity: Activity, container: FrameLayout) {
        nativeAdCached?.let { ad ->
            container.removeAllViews()
            val inflater = LayoutInflater.from(activity)
            val adView = inflater.inflate(R.layout.native_ad_layout, container, false) as NativeAdView

            val mediaView = adView.findViewById<MediaView>(R.id.ad_media)
            val iconView = adView.findViewById<ImageView>(R.id.ad_icon)
            val headlineView = adView.findViewById<TextView>(R.id.ad_headline)
            val bodyView = adView.findViewById<TextView>(R.id.ad_body)
            val advertiserView = adView.findViewById<TextView>(R.id.ad_advertiser)
            val ctaView = adView.findViewById<Button>(R.id.ad_call_to_action)

            adView.mediaView = mediaView
            adView.iconView = iconView
            adView.headlineView = headlineView
            adView.bodyView = bodyView
            adView.advertiserView = advertiserView
            adView.callToActionView = ctaView

            headlineView.text = ad.headline
            ad.body?.let { bodyView.text = it } ?: run { bodyView.visibility = View.GONE }
            ad.advertiser?.let { advertiserView.text = it } ?: run { advertiserView.visibility = View.GONE }
            ad.callToAction?.let { ctaView.text = it } ?: run { ctaView.visibility = View.GONE }

            if (ad.icon != null) {
                ad.icon?.drawable?.let { iconView.setImageDrawable(it) }
                iconView.visibility = View.VISIBLE
            } else {
                iconView.visibility = View.GONE
            }

            adView.setNativeAd(ad)

            container.addView(adView)
            container.visibility = View.VISIBLE

            nativeAdCached = null
            preloadNative(activity.applicationContext)
        } ?: run {
            preloadNative(activity.applicationContext)
            container.visibility = View.GONE
        }
    }
}
