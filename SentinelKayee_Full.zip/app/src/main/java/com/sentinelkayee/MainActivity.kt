package com.sentinelkayee

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.CountDownTimer
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webview: WebView
    private lateinit var urlInput: EditText
    private lateinit var nextBtn: Button
    private lateinit var adContainer: FrameLayout
    private lateinit var nativeHolder: FrameLayout

    private var playedCount = 0
    private var currentTimer: CountDownTimer? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlInput = findViewById(R.id.urlInput)
        nextBtn = findViewById(R.id.nextBtn)
        webview = findViewById(R.id.webview)
        adContainer = findViewById(R.id.ad_container)
        nativeHolder = findViewById(R.id.native_ad_holder)

        val settings: WebSettings = webview.settings
        settings.javaScriptEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false
        webview.webChromeClient = WebChromeClient()

        nextBtn.setOnClickListener {
            loadAndStart(urlInput.text.toString())
        }

        AdManager.attachAdaptiveBanner(this, adContainer)
    }

    override fun onResume() {
        super.onResume()
        AdManager.showAppOpenIfAvailable(this)
    }

    override fun onPause() {
        super.onPause()
        currentTimer?.cancel()
    }

    private fun loadAndStart(rawUrl: String) {
        val embedHtml = createYouTubeEmbedHtml(extractVideoId(rawUrl))
        webview.loadDataWithBaseURL("", embedHtml, "text/html", "utf-8", null)

        currentTimer?.cancel()
        currentTimer = object : CountDownTimer(60_000, 1000) {
            override fun onTick(millisUntilFinished: Long) {}
            override fun onFinish() {
                playedCount++
                if (playedCount % 3 == 0) {
                    AdManager.showRewardedInterstitial(this@MainActivity) {
                        AdManager.showNative(this@MainActivity, nativeHolder)
                    }
                }
            }
        }.start()
    }

    private fun extractVideoId(raw: String): String {
        if (raw.contains("v=")) {
            val idx = raw.indexOf("v=") + 2
            val end = raw.indexOf('&', idx).takeIf { it > idx } ?: raw.length
            return raw.substring(idx, end)
        }
        if (raw.contains("youtu.be/")) {
            val idx = raw.indexOf("youtu.be/") + 9
            val end = raw.indexOf('?', idx).takeIf { it > idx } ?: raw.length
            return raw.substring(idx, end)
        }
        return raw.trim()
    }

    private fun createYouTubeEmbedHtml(videoId: String): String {
        return """<html><body style=\"margin:0;padding:0;overflow:hidden;\">""" +
                "<iframe width=\"100%\" height=\"100%\" src=\"https://www.youtube-nocookie.com/embed/$videoId?rel=0&autoplay=1&controls=1&modestbranding=1\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen></iframe>" +
                "</body></html>"
    }
}
