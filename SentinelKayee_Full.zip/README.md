Sentinel Kayee - Full project generated
---------------------------------------
This ZIP contains a ready-to-edit Android project skeleton with:
- AppOpen ad shown on app launch (preloaded)
- Adaptive banner at bottom
- Native ads (full asset binding)
- Rewarded interstitial shown every 3 videos (and native after)
- YouTube embed via WebView auto-play for 60s

To build: open in Android Studio, sync Gradle, and run on device.
Make sure to test with test ad units or register your device as a test device.
